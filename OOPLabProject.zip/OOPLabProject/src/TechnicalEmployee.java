
public class TechnicalEmployee extends Employee{
	
public int checkIns;

	public TechnicalEmployee(String name) {
		super(name, 75000);
		 
	}
	public void CheckIns() {
		checkIns++;
	}

	public String employeeStatus() {
		return super.toString() + " has " + checkIns + " successful check ins ";
	}
	
	
}
