
public class SoftwareEngineer extends TechnicalEmployee{
	
private boolean codeAccess;

	public SoftwareEngineer(String name) {
		super(name);
        checkIns=0;
		codeAccess = false;
	}
	
	public boolean getCodeAccess() {
		return codeAccess;
	}
	public void setCodeAccess(boolean codeAccess) {
		this.codeAccess = codeAccess;
	}

    public int getSuccessfulCheckIns() {	
		return checkIns;
	}
 
	public boolean checkInCode() {
		TechnicalLead manager=(TechnicalLead) this.getManager();
		if(manager.approveCheckIn(this)){	
		this.checkIns++;
		return true;
		}else{
		codeAccess = false;
		return false;
	}	
}

   
}