import java.util.ArrayList;

public class BusinessLead extends BusinessEmployee{
	public ArrayList<Accountant> busiLeadData = new ArrayList<Accountant>();
	
	public int headCount;
	
	public BusinessLead(String name) {
		super(name);
		this.baseSalary = getBaseSalary()*2;
		this.headCount = 10;
	}

	public boolean hasHeadCount() {
		if(this.busiLeadData.size() < this.headCount) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean addReport(Accountant e, TechnicalLead supportTeam) {
		if(hasHeadCount()) {
			busiLeadData.add(e);
			e.setManager(this);
			this.bonusBudget += e.baseSalary *1.1;
			e.supportTeam(supportTeam);
			supportTeam.accountSupport = e;
			return true;
		}else {
			return false;
		}
	}

	
	public boolean requestBonus(Employee e, double bonus) {
		if(bonus <=getBonusBudget()) {
			this.bonusBudget = bonus;
			return true;
		}else {
			return false;
		}
	}
	
	public boolean approveBonus(Employee e, double bonus) {
		for(int i=0; i<busiLeadData.size(); i++) {
			if((busiLeadData.get(i).getTeamSupported()).equals(e.manager) && busiLeadData.get(i).approveBonus(bonus)) {
				e.bonus = bonus;
				return true;
			}
		}
		return false;
	}
	
	public String getTeamStatus() {
		  if (busiLeadData.size()==0){
	            return this.employeeStatus()+ " and no direct reports yet";
	        } else {
	            String teamStatus="";
	            for (int i=0;i<busiLeadData.size();i++){
	                teamStatus+=("    "+busiLeadData.get(i).employeeStatus()+"\n");
	            }
	            return this.employeeStatus()+" and is managing: \n"+teamStatus;
	        }
	}
	
}



















