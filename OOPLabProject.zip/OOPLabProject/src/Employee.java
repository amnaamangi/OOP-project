
public abstract class Employee {
   private String name;
   public double baseSalary;
   private int employeeId;
   private static int id;
   public Employee manager;
   public Accountant accountSupport;
   public double bonus;
   
public Employee(String name, double baseSalary) {
	this.name = name;
	this.baseSalary = baseSalary;
	id++;
	this.employeeId = id;
}

public double getBaseSalary() {
	return baseSalary;
}

public String getName() {
	return name;
}

public int getEmployeeId() {
	return employeeId;
}

public Employee getManager() {
	return manager;
}

public void setManager(Employee manager) {
	this.manager=manager;
}

public Employee getAccountSupport() {
	return accountSupport;
}

public boolean equals(Employee other) {
	return this.getEmployeeId() == other.getEmployeeId();
}


public abstract String employeeStatus();


public String toString() {
	return employeeId + " " + name;
}

}




















