
public class Accountant extends BusinessEmployee{
public TechnicalLead support;

public Accountant(String name) {
	super(name);
	bonusBudget = 0;
}

public TechnicalLead getTeamSupported() {
	return support;
}

public void supportTeam(TechnicalLead lead) {
    this.support=lead;
	for(int i=0; i<lead.techLeadData.size(); i++) {
		this.bonusBudget += lead.techLeadData.get(i).getBaseSalary()*1.1;
	}
}

public boolean approveBonus(double bonus) {
	double suggestedBonus = bonus;
	if(suggestedBonus >= getBonusBudget()) {
		return false;
	}else {
		return true;
	}
}

@Override
public String employeeStatus() {
	return this.toString() + " with a budget of " + getBonusBudget() + " is supporting " + this.getTeamSupported();                    
}

}
