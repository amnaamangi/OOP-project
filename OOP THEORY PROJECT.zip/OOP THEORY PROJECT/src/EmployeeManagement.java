import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

public class EmployeeManagement {
	static ArrayList<Employee> data = new ArrayList<Employee>();

       	// ADD EMPLOYEE

		private static void addEmployee(ArrayList<Employee> data) {
			Employee emp = new Employee();
			String id;
 	        Scanner sc = new Scanner(System.in);
 	        
 	        System.out.println("PLEASE ENTER EMPLOYEE ID:");
 	        id = sc.next();
 	        
 	       if(!isUsed(data,id)){	    	   
 	    	  emp.setId(id);
 	    
 	           System.out.println("ENTER NAME");
 	           emp.setName(sc.next());
 	           
 	           System.out.println("ENTER GENDER");
 	           emp.setGender(sc.next());
 	           
 	           System.out.println("ENTER DESIGNATION");
 	           emp.setDesignation(sc.next());
 	           
 	           System.out.println("ENTER PHONE NUMBER");
	           emp.setPhoneNumber(sc.next());
	           
 	           System.out.println("ENTER SALARY");
 	           emp.setSalary(sc.nextDouble());  
 	           
 	           data.add(emp);
		       System.out.println ("SUCCESSFULLY ADDED!");		
		      
	}
}
		
		// EMPLOYEE ID REPEAT MECHANISM

	    private static boolean isUsed(ArrayList<Employee> data ,String id) {
	        boolean hasUsed = false;
	        if(data!=null){
	            for (int i = 0; i < data.size(); i++) {
	                Employee emp1 = data.get(i);
	                if(emp1.getId() == null){
	                    break;
	                }
	                if (emp1.getId().equals(id)) {
	                    System.out.println("DUPLICATE EMPLOYEE ID, PLEASE TRY AGAIN");
	                    hasUsed = true;
	                    break;
	                }
	            }
	        }
	        return hasUsed;
	    }
	 
	      // MODIFY EMPLOYEE INFORMATION 
	    
			private static void updateRecord(ArrayList<Employee> data, String id){
				boolean record = false;
                try {
				Scanner sc = new Scanner(System.in);
		        for(Employee e : data){
		            if(e == null){
		                break;
		            }            
		        if(e.getId().equals(id)){   		  
		        	System.out.println("ENTER NAME");
		 	           e.setName(sc.next());
		 	           
		 	           System.out.println("ENTER GENDER");
		 	           e.setGender(sc.next());
		 	           
		 	           System.out.println("ENTER DESIGNATION");
		 	           e.setDesignation(sc.next());
		 	           
		 	           System.out.println("ENTER PHONE NUMBER");
			           e.setPhoneNumber(sc.next());
		 	           
		 	           System.out.println("ENTER SALARY");
		 	           e.setSalary(sc.nextDouble()); 
		 	           
		 	          System.out.println("MODIFIED");
		 	          record = true;
		 	          return;
			  }
		     }
				}catch(Exception err) {
	   			System.out.println(err.getMessage());
	}
}

			// DISPLAY ALL EMPLOYEE INFORMATION
			
			private static void displayRecord(ArrayList<Employee> data) {
				for (Employee e : data) {
		            System.out.println(e);
		        }
				 
			}

			//QUERY EMPLOYEE INFORMATION
			
			public static void searchRecord(ArrayList<Employee> data , String id) throws Exception {
				boolean record = false;
				
				for (Employee e : data) {
		            if(e == null){
		                System.out.println("QUERY COMPLETED");
		                break;
		            }
		            if(e.getId().equals(id)){
		                System.out.println(e);
		                record = true;
		                System.out.println("INFORMATION FOUND");
		                return;
		            }
				}
				throw new Exception("EMPLOYEE NOT FOUND");
          }
			
			//DELETE EMPLOYEE INFORMATION
			
			public static void deleteRecord(ArrayList<Employee> data, String id) throws Exception{
				boolean record = false;
				
				for (Employee e : data) {
		            if(e == null){
		                break;
		            }
		            if(e.getId().equals(id)){
		                data.remove(e);
		                record = true;
		                System.out.println("INFORMATION DELETED");
		                return;
		            }
		        }
				throw new Exception("EMPLOYEE NOT FOUND");
			}
			
	public static void main(String args[])  {	
					
		String months[] = {
	            "Jan",
	            "Feb",
	            "Mar",
	            "Apr",
	            "May",
	            "Jun",
	            "Jul",
	            "Aug",
	            "Sep",
	            "Oct",
	            "Nov",
	            "Dec"
	        };   
		
	        Calendar calendar = Calendar.getInstance();
	         
	        System.out.println("\n--------------------------------------------------------------------------------");
	        System.out.println("            *** Welcome to Employee Management System ***          ");
	        System.out.println("--------------------------------------------------------------------------------");
	        
	        System.out.print("Date: " + months[calendar.get(Calendar.MONTH)] + " " + calendar.get(Calendar.DATE) + " " + calendar.get(Calendar.YEAR));
	        System.out.println("\t\t\t\t\t\tTime: " + calendar.get(Calendar.HOUR) + ":" + calendar.get(Calendar.MINUTE) + ":" + calendar.get(Calendar.SECOND));

	        Employee emp = new Employee();

	        emp.login();
	        emp.companyDetail();
	        
	        int again = 1;
			while(again == 1) {

				System.out.println("***********************************");
		        System.out.println("* MAIN MENU *");
		        System.out.println("***********************************");
		        System.out.println("1. ADD EMPLOYEE INFORMATION");
		        System.out.println("2. DELETE EMPLOYEE INFORMATION ");
		        System.out.println("3. MODIFY EMPLOYEE INFORMATION ");
		        System.out.println("4. QUERY EMPLOYEE INFORMATION ");
		        System.out.println("5. VIEW ALL EMPLOYEE INFORMATION ");
		        System.out.println("6. EXIT ");
		        System.out.println("Please enter an action item");
			  		

	        Scanner sc = new Scanner(System.in);
	        int choose = sc.nextInt();
	        switch (choose) {
	            case 1:
	                System.out.println("PLEASE ADD EMPLOYEE INFORMATION ");
	                addEmployee(data);
	                break;
	            case 2:
	                System.out.println("DELETE EMPLOYEE INFORMATION");
	                System.out.println("PLEASE ENTER EMPLOYEE ID");
	                try {
	                String id = sc.next();
	                deleteRecord(data,id);
	                }catch (Exception e) {
						e.printStackTrace();
					}
	                break;
	            case 3:
	                System.out.println("MODIFY EMPLOYEE INFORMATON");
	                System.out.println("PLEASE ENTER EMPLOYEE ID");
	                String id = sc.next();
	                updateRecord(data,id);
	                break;
	            case 4:
	                System.out.println("QUERY EMPLOYEE INFORMATON");
	                System.out.println("PLEASE ENTER EMPLOYEE ID");	  
	                try {
	                String id1 = sc.next();
	                searchRecord(data,id1);
	                }catch (Exception e) {
						e.printStackTrace();
					}
	                break;
	            case 5:
	                System.out.println("VIEW ALL EMPLOYEE INFORMATION");
	                displayRecord(data);
	                break;
	            case 6:
					System.out.println("THANKYOU FOR USING THE SYSTEM");
					System.exit(0);
					break;
	            default:
	                System.out.println("THE CORRESPONDING OPERATION ITEM WAS NOT FOUND");
	        }
	        System.out.println(" Return to MAIN MENU Press 1");
	        again = sc.nextInt();
	    }
	}
}