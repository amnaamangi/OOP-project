public class Employee extends Company{
 
	private String id;
	private String name;
	private String gender;
	private String designation;
	private String phoneNumber;
	private double salary;
	
	public Employee(String id, String name, String gender, String designation, String phoneNumber, double salary){
		this.id = id;
		this.name = name;
		this.designation = designation;
		this.gender = gender;
		this.phoneNumber = phoneNumber;
		this.salary=salary;
	}
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public double calculateSalary(int holiday){
		return 1;
	}
	
	@Override
	public String toString() {
        return getId() + "\t" + getName() + "\t" + getGender() + "\t" + getDesignation() + "\t" + getPhoneNumber() + "\t" + getSalary();
        
      
}
}