import java.util.Scanner;

abstract class Company 
{   
	public void login() {
	    
		String username = "project";
	    String password = "oop";

	    Scanner scan = new Scanner(System.in);
	    
	    System.out.println("Enter Username : ");
	    username = scan.next();
	    
	    System.out.println("Enter Password : ");
	    password = scan.next();
	    
	    if (username.equals("project") && password.equals("oop")) {
	        System.out.println("Access Granted!");
	    }
	    
	    else if (username.equals("project")) {
	        System.out.println("Invalid Password!");
	        System.exit(0);
	    } 
	    
	    else if (password.equals("oop")) {
	        System.out.println("Invalid Username!");
	        System.exit(0);
	    } 
	    
	    else {
	        System.out.println("Invalid Username & Password!");
	        System.exit(0);
	    }
	   
}
	   	
    public void companyDetail()
    {
    	System.out.println("                  ******COMPANY DETAILS******                    ");
        System.out.println("COMPANY NAME: FOLIO 3");
        System.out.println("COMPANY ADDRESS: 163 Town, Main Shahrah-e-Faisal,Karachi,Pakistan");
        System.out.println("COMPANY PHONE: 24802340292");
        System.out.println("COMPANY FAX: 202438594131");
        System.out.println("COMPANY EMAIL: www.folio3.com");

}
}